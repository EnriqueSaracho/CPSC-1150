/**
 * Program name: Exercise1
 * 
 * @author Enrique Saracho Felix
 *         Course: CPSC 1150
 *         Date: May 12, 2023
 * 
 */
public class Exercise1 {
    /**
     * main: The main program which displays the students initials.
     */
    public static void main(String[] args) {
        // display the student initials.
        System.out.println("EEEEEE  SSSS  FFFFFF");
        System.out.println("EE     SS     FF    ");
        System.out.println("EEEEEE  SSS   FFFFF ");
        System.out.println("EE         SS FF    ");
        System.out.println("EEEEEE  SSSS  FF    ");
    }
}