public class Sample {
	public static void main(String[] args) {
		System.out.println("Hello from ABC in CPSC 1150!");
		System.out.println(1 / 0);
		System.out.println("The summation of 1 and 2 is " + 1 + 2);
		int x = 10, y = 15;
		System.out.println("The average of " + x + " and " + y +
				" is " + (x + y) / 2);
	}
}